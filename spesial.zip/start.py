from telegram import Update, constants
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    CallbackContext,
    ConversationHandler,
    ContextTypes
)
import logging
import requests
import os
import shutil
import json
from typing import List, Dict, Optional
import httpx
import re
import validators
import aiohttp  # Pastikan untuk menginstall aiohttp: pip install aiohttp
from datetime import datetime  # Import datetime untuk mendapatkan waktu saat ini

# Konstanta File
USAGE_FILE = 'usage_counts.json'
ADMIN_FILE = 'admin.md'
BANNED_FILE = 'group.md'
SHORTLINK_FILE = 'shortlink.json'
GROUPS_FILE = 'groups.json'

# Menambahkan job queue untuk menjalankan pemeriksaan setiap 10 menit
def schedule_jobs(application: Application) -> None:
    application.job_queue.run_repeating(check_all_groups, interval=600, first=10)

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Fungsi untuk memeriksa apakah grup diizinkan menggunakan bot
async def is_group(group_id: int) -> bool:
    """Cek apakah group_id ada di allowed_groups dari groups.json."""
    try:
        with open(GROUPS_FILE, 'r') as groups_file:
            groups_data = json.load(groups_file)
            allowed_groups = groups_data.get("allowed_groups", [])
            return group_id in allowed_groups
    except FileNotFoundError:
        # Jika file groups.json tidak ditemukan, anggap tidak ada grup yang diizinkan
        return False
    except json.JSONDecodeError:
        # Jika terjadi kesalahan saat parsing JSON, anggap tidak ada grup yang diizinkan
        return False

# Fungsi untuk memeriksa apakah grup adalah admin
async def is_admin(group_id: int) -> bool:
    """Cek apakah group_id ada di admin.md."""
    try:
        with open(ADMIN_FILE, 'r') as admin_file:
            admin_groups = admin_file.read().strip().splitlines()
            return str(group_id) in admin_groups
    except FileNotFoundError:
        # Jika file admin.md tidak ditemukan, anggap tidak ada admin
        return False

# Fungsi untuk menambahkan ID grup ke file admin.md
async def add_to_admin(target_id: str) -> None:
    with open(ADMIN_FILE, 'a') as admin_file:
        admin_file.write(f'{target_id}\n')

# Fungsi untuk menghapus ID grup dari file admin.md
async def remove_from_admin(target_id: str) -> None:
    try:
        with open(ADMIN_FILE, 'r') as admin_file:
            admin_groups = admin_file.read().strip().splitlines()
        admin_groups = [id for id in admin_groups if id != target_id]
        with open(ADMIN_FILE, 'w') as admin_file:
            admin_file.write("\n".join(admin_groups))
    except FileNotFoundError:
        pass  # File tidak ada, tidak perlu diproses lebih lanjut

# Fungsi untuk menambahkan ID grup ke file banned (group.md)
async def add_to_banned(target_id: str) -> None:
    with open(BANNED_FILE, 'a') as banned_file:
        banned_file.write(f'{target_id}\n')

# Fungsi untuk menghapus ID grup dari file banned (group.md)
async def remove_from_banned(target_id: str) -> None:
    try:
        with open(BANNED_FILE, 'r') as banned_file:
            banned_groups = banned_file.read().strip().splitlines()
        banned_groups = [id for id in banned_groups if id != target_id]
        with open(BANNED_FILE, 'w') as banned_file:
            banned_file.write("\n".join(banned_groups))
    except FileNotFoundError:
        pass  # File tidak ada, tidak perlu diproses lebih lanjut

# Fungsi untuk memuat daftar admin
def load_admin_list() -> List[str]:
    if not os.path.exists(ADMIN_FILE):
        return []
    with open(ADMIN_FILE, 'r') as file:
        admins = [line.strip() for line in file if line.strip()]
    return admins

# Fungsi untuk memuat daftar grup spesial (jika diperlukan)
def load_spesial_list() -> List[str]:
    SPESIAL_FILE = 'spesial.md'
    if not os.path.exists(SPESIAL_FILE):
        return []
    with open(SPESIAL_FILE, 'r') as file:
        spesial_groups = [line.strip() for line in file if line.strip()]
    return spesial_groups

# Global Variable untuk Spesial List
SPESIAL_LIST: List[str] = []

def load_spesials() -> None:
    """Muat daftar spesial ke dalam SPESIAL_LIST."""
    global SPESIAL_LIST
    SPESIAL_LIST = load_spesial_list()

# Fungsi untuk memeriksa apakah grup adalah spesial
def is_spesial(group_id: int) -> bool:
    """Cek apakah group_id ada di spesial.md."""
    return str(group_id) in SPESIAL_LIST

# Fungsi untuk menambahkan ID grup ke file spesial.md
async def add_to_spesial(target_id: str) -> None:
    SPESIAL_FILE = 'spesial.md'
    if not os.path.exists(SPESIAL_FILE):
        with open(SPESIAL_FILE, 'w') as file:
            pass  # Membuat file jika belum ada
    with open(SPESIAL_FILE, 'a') as file:
        file.write(f'{target_id}\n')
    # Perbarui SPESIAL_LIST setelah menambahkan
    SPESIAL_LIST.append(target_id)

# Fungsi untuk memuat shortlinks dari shortlink.json
def load_shortlinks() -> Dict[str, Dict[str, str]]:
    """Muat shortlinks dari shortlink.json."""
    if not os.path.exists(SHORTLINK_FILE):
        return {}
    with open(SHORTLINK_FILE, 'r') as file:
        try:
            return json.load(file)
        except json.JSONDecodeError:
            return {}

# Fungsi untuk menyimpan shortlinks ke shortlink.json
def save_shortlinks(data: Dict[str, Dict[str, str]]) -> None:
    """Simpan shortlinks ke shortlink.json."""
    with open(SHORTLINK_FILE, 'w') as file:
        json.dump(data, file, indent=4)

# Fungsi untuk menambahkan shortlink baru
def add_shortlink(name: str, domainutama: str, domaincadangan: str) -> None:
    """Tambah shortlink baru ke shortlink.json."""
    shortlinks = load_shortlinks()
    shortlinks[name] = {
        "domainutama": domainutama,
        "domaincadangan": domaincadangan
    }
    save_shortlinks(shortlinks)

# Fungsi untuk mendapatkan semua shortlinks
def get_all_shortlinks() -> Dict[str, Dict[str, str]]:
    """Dapatkan semua shortlinks."""
    return load_shortlinks()

# Fungsi untuk mengupdate shortlink yang sudah ada
def update_shortlink(name: str, new_domainutama: str, new_domaincadangan: str) -> bool:
    """
    Update shortlink yang sudah ada.
    
    Args:
        name (str): Nama shortlink.
        new_domainutama (str): Domain utama baru.
        new_domaincadangan (str): Domain cadangan baru.
    
    Returns:
        bool: True jika berhasil, False jika nama tidak ditemukan.
    """
    shortlinks = load_shortlinks()
    if name not in shortlinks:
        return False
    shortlinks[name]["domainutama"] = new_domainutama
    shortlinks[name]["domaincadangan"] = new_domaincadangan
    save_shortlinks(shortlinks)
    return True

# Fungsi untuk mendapatkan domain cadangan
def get_backup_domain(name: str) -> Optional[str]:
    """Dapatkan domain cadangan berdasarkan nama shortlink. Mengembalikan None jika nama tidak ditemukan."""
    shortlinks = load_shortlinks()
    return shortlinks.get(name, {}).get("domaincadangan")

# Fungsi untuk memeriksa dan meningkatkan hitungan penggunaan
def load_usage_counts() -> Dict[str, Dict[str, int]]:
    if not os.path.exists(USAGE_FILE):
        return {}
    with open(USAGE_FILE, 'r') as file:
        try:
            return json.load(file)
        except json.JSONDecodeError:
            return {}

def save_usage_counts(data: Dict[str, Dict[str, int]]) -> None:
    with open(USAGE_FILE, 'w') as file:
        json.dump(data, file, indent=4)

def check_and_increment_usage(group_id: int, feature: str, max_usage: int) -> bool:
    usage_data = load_usage_counts()
    group_id_str = str(group_id)
    
    if group_id_str not in usage_data:
        usage_data[group_id_str] = {}
    
    if feature not in usage_data[group_id_str]:
        usage_data[group_id_str][feature] = 0
    
    if usage_data[group_id_str][feature] >= max_usage:
        return False  # Sudah mencapai batas
    
    usage_data[group_id_str][feature] += 1
    save_usage_counts(usage_data)
    return True

# Fungsi untuk memeriksa semua grup dan mengganti shortlink jika diperlukan
async def check_all_groups(context: CallbackContext) -> None:
    """
    Fungsi untuk memeriksa semua grup dan mengganti shortlink jika domain utama diblokir.
    
    Args:
        context (CallbackContext): Konteks callback dari Telegram.
    """
    # Mendapatkan semua file .txt di direktori saat ini
    txt_files = [file for file in os.listdir('.') if file.endswith('.txt')]

    # Memuat shortlinks dari shortlink.json
    shortlinks = load_shortlinks()

    for file_name in txt_files:
        group_id = file_name.split('.')[0]  # Mengambil group_id dari nama file
        try:
            with open(file_name, 'r') as file:
                domains = file.read().strip()  # Membaca semua domain dalam file

                if domains:
                    # Kirim permintaan GET ke URL untuk memeriksa blokir
                    url = 'https://check.skiddle.id/'
                    params = {'domains': domains}
                    response = requests.get(url, params=params)

                    if response.status_code == 200:
                        try:
                            # Memparsing respons JSON
                            data = response.json()
                            blocked_domains = [domain for domain, status in data.items() if status.get('blocked')]

                            # Jika ada domain yang diblokir, kirim pesan ke grup
                            if blocked_domains:
                                # Menyiapkan pesan yang diformat
                                output_lines = [
                                    "⚠️ Domain berikut terblokir oleh Kominfo ⚠️:",
                                    *blocked_domains,
                                    "\n✨ Agar tidak mendapatkan pesan ini lagi, silakan gunakan perintah /hapus lalu hapus domain dengan mengirimkan Y ✨"
                                ]
                                output_text = "\n".join(output_lines)

                                # Kirim pesan ke grup
                                await context.bot.send_message(
                                    chat_id=int(group_id),
                                    text=output_text,
                                    parse_mode=constants.ParseMode.MARKDOWN
                                )

                                # Cek dan ganti shortlink jika diperlukan
                                for blocked_domain in blocked_domains:
                                    for name, domains_info in shortlinks.items():
                                        if blocked_domain == domains_info['domainutama']:
                                            backup_domain = domains_info['domaincadangan']

                                            # Validasi backup_domain sebelum mengirim ke API
                                            if not validators.domain(backup_domain):
                                                logger.error(f"Domain cadangan `{backup_domain}` tidak valid untuk shortlink `{name}`.")
                                                continue  # Lewati penggantian jika domain cadangan tidak valid

                                            # Kirim permintaan POST untuk mengganti domain
                                            try:
                                                logger.info(f"Mengirim permintaan POST untuk mengganti shortlink `{name}` dengan domain cadangan `{backup_domain}`.")
                                                response_replace = requests.post(
                                                    "https://foxlink.pro/api.php",
                                                    data={"name": name, "domain": backup_domain, "replace": "true"}
                                                )

                                                logger.info(f"Response Status: {response_replace.status_code}, Response Body: {response_replace.text}")

                                                if response_replace.status_code == 200:
                                                    # Swap domainutama dengan domaincadangan di shortlink.json
                                                    old_domainutama = shortlinks[name]["domainutama"]
                                                    new_domainutama = shortlinks[name]["domaincadangan"]
                                                    new_domaincadangan = old_domainutama

                                                    update_success = update_shortlink(name, new_domainutama, new_domaincadangan)
                                                    if update_success:
                                                        logger.info(f"Shortlink `{name}` telah diganti dengan domain cadangan `{backup_domain}`.")
                                                        
                                                        # Menyiapkan pesan penggantian
                                                        swap_message = f"🌐ShortLink Terdeteksi!, Mengganti foxlink.pro/{name} menjadi {backup_domain}🌐"
                                                        
                                                        # Kirim pesan penggantian ke grup
                                                        await context.bot.send_message(
                                                            chat_id=int(group_id),
                                                            text=swap_message,
                                                            parse_mode=constants.ParseMode.MARKDOWN
                                                        )
                                                    else:
                                                        logger.error(f"Gagal mengupdate shortlink `{name}`. Nama tidak ditemukan.")
                                                else:
                                                    logger.error(f"Gagal mengganti isi Link shortlink `{name}`. Status Code: {response_replace.status_code}\nResponse: {response_replace.text}")
                                            except Exception as e:
                                                logger.error(f"Terjadi kesalahan saat mengganti shortlink `{name}`: {e}")

                        except Exception as e:
                            logger.error(f"Error memparsing respons JSON untuk file {file_name}: {e}")
                    else:
                        logger.error(f"Error: Menerima status kode {response.status_code} untuk file {file_name}\nResponse: {response.text}")
                else:
                    logger.info(f"Tidak ada domain yang ditemukan dalam file {file_name}")
        except Exception as e:
            logger.error(f"Error memeriksa file {file_name}: {e}")

# Fungsi helper untuk melakukan permintaan GET secara asinkron
async def send_get_request(user: str, domain: str) -> None:
    url = "https://foxproject.site/nawadd/"
    current_time = datetime.now().strftime("%I:%M%p-%Y")  # Format: "12:30AM-2024"
    name = f"BOT-{current_time}"
    params = {
        "user": user,
        "name": name,  # Menggunakan format BOT-{time}-{year}
        "domain": domain
    }
    logger.info(f"Mengirim permintaan GET ke {url} dengan parameter: {params}")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                if response.status == 200:
                    logger.info(f"Permintaan GET untuk domain '{domain}' berhasil dengan status {response.status}.")
                else:
                    logger.warning(f"Permintaan GET untuk domain '{domain}' gagal dengan status {response.status}.")
    except Exception as e:
        logger.error(f"Error mengirim permintaan GET untuk domain '{domain}': {e}")

# Fungsi helper untuk mendapatkan 'user' dari user_get.json
def get_user_from_json() -> Optional[str]:
    json_file = 'user_get.json'
    
    if not os.path.exists(json_file):
        logger.error(f"File {json_file} tidak ditemukan.")
        return None
    
    try:
        with open(json_file, 'r') as file:
            data = json.load(file)
            user = data.get("user_get")  # Mengambil nilai dari kunci 'user_get'
            if user:
                logger.info(f"User berhasil diambil dari {json_file}: {user}")
            else:
                logger.warning(f"Kunci 'user_get' tidak ditemukan dalam {json_file}.")
            return user
    except json.JSONDecodeError as e:
        logger.error(f"Error decoding JSON dari {json_file}: {e}")
        return None
    except Exception as e:
        logger.error(f"Error membaca {json_file}: {e}")
        return None

# ======================================
# Fungsi Utama
# ======================================

async def add_domain(update: Update, context: CallbackContext) -> None:
    if update.message:
        chat = update.message.chat
        group_id: int = chat.id  # Mendapatkan group_id dari grup
        group_name: Optional[str] = chat.title  # Mendapatkan nama grup
        
        # Mendapatkan 'user' dari user_get.json
        user = get_user_from_json()
        
        if not user:
            await update.message.reply_text(
                "❌ Tidak dapat menemukan informasi pengguna. Silakan hubungi administrator. ❌"
            )
            logger.error("Proses penambahan domain dibatalkan karena 'user' tidak ditemukan.")
            return
        
        logger.info(f"Memproses penambahan domain untuk grup ID: {group_id}, Nama Grup: {group_name}")
        
        # Cek apakah grup diizinkan menggunakan bot
        if not await is_group(group_id):
            await update.message.reply_text(
                "🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n"
                "💬 Silahkan Hubungi Developer Dengan Command /chat 💬"
            )
            logger.warning(f"Grup ID {group_id} tidak diizinkan menggunakan bot.")
            return
        
        # Cek apakah grup adalah admin
        is_admin_group: bool = str(group_id) in load_admin_list()
        if is_admin_group:
            logger.info(f"Grup ID {group_id} adalah grup admin.")
        else:
            logger.info(f"Grup ID {group_id} bukan grup admin.")
        
        if context.args:
            # Cek dan tingkatkan hitungan penggunaan jika bukan admin
            if not is_admin_group:
                FEATURE = 'add_domain'
                MAX_USAGE = 20  # Batas penggunaan dalam Mode Trial
                if not check_and_increment_usage(group_id, FEATURE, MAX_USAGE):
                    await update.message.reply_text(
                        "Dalam Mode Trial Grup Ini Hanya Dapat Memakai Fitur Ini Sebanyak 5x!"
                    )
                    logger.warning(f"Grup ID {group_id} telah mencapai batas penggunaan fitur '{FEATURE}'.")
                    return
            
            # Gabungkan semua argumen yang dimasukkan oleh pengguna
            domains_str: str = " ".join(context.args)  # Gabungkan menjadi satu string
            file_name: str = f'{group_id}.txt'  # Nama file berdasarkan group_id

            # Memeriksa apakah argumen terakhir adalah '*'
            add_to_all_files: bool = context.args[-1] == '*'
            if add_to_all_files:
                domains_str = " ".join(context.args[:-1])  # Hilangkan '*' dari daftar domain yang akan ditambahkan
                logger.info(f"Menambahkan domain ke semua grup: {domains_str}")
            else:
                logger.info(f"Menambahkan domain ke grup ID {group_id}: {domains_str}")

            # Ganti spasi antar domain dengan koma
            domains_str = domains_str.replace(' ', ',')
            new_domains: List[str] = [domain.strip() for domain in domains_str.split(',') if domain.strip()]
            logger.debug(f"Daftar domain baru yang diinput: {new_domains}")

            try:
                if add_to_all_files:
                    # Menambahkan domain ke semua file .txt di direktori
                    txt_files: List[str] = [f for f in os.listdir('.') if f.endswith('.txt')]
                    logger.info(f"Mendapatkan daftar file .txt: {txt_files}")

                    if not txt_files:
                        await update.message.reply_text("Tidak ada Grup ditemukan.")
                        logger.warning("Tidak ada file .txt ditemukan di direktori.")
                        return

                    for file_name in txt_files:
                        # Membaca file dan menambahkan domain baru
                        with open(file_name, 'r') as file:
                            existing_domains: List[str] = [domain.strip() for domain in file.read().strip().split(',') if domain.strip()]
                        logger.debug(f"Domain yang sudah ada dalam {file_name}: {existing_domains}")

                        # Menambahkan domain baru yang belum ada
                        unique_domains: List[str] = [domain for domain in new_domains if domain not in existing_domains]
                        logger.debug(f"Domain unik yang akan ditambahkan ke {file_name}: {unique_domains}")

                        if unique_domains:
                            with open(file_name, 'a') as file:
                                if existing_domains:
                                    file.write(f',{",".join(unique_domains)}')
                                else:
                                    file.write(f'{",".join(unique_domains)}')
                            logger.info(f"Menambahkan domain {unique_domains} ke {file_name}")

                            # Mengirim permintaan GET untuk setiap domain yang ditambahkan
                            for domain in unique_domains:
                                await send_get_request(user, domain)
                        else:
                            logger.info(f"Semua domain sudah ada dalam {file_name}. Tidak ada yang ditambahkan.")

                    await update.message.reply_text(f"Domain(s) {', '.join(new_domains)} telah ditambahkan ke semua Grup. 🎉")
                    logger.info(f"Domain {new_domains} berhasil ditambahkan ke semua grup.")
                
                else:
                    # Menambahkan domain hanya ke file group_id.txt
                    try:
                        with open(file_name, 'r') as file:
                            existing_domains: List[str] = [domain.strip() for domain in file.read().strip().split(',') if domain.strip()]
                        logger.debug(f"Domain yang sudah ada dalam {file_name}: {existing_domains}")
                    except FileNotFoundError:
                        existing_domains = []
                        logger.info(f"File {file_name} tidak ditemukan. Akan dibuat baru.")

                    if not is_admin_group:
                        # Cek jumlah domain yang sudah ada
                        if len(existing_domains) >= 3:
                            await update.message.reply_text(
                                f"Dalam Mode Trial Grup Ini Hanya Dapat Menambahkan MAX 3 domain! "
                                f"Silahkan hapus salah satu domain: {', '.join(existing_domains)}"
                            )
                            logger.warning(f"Grup ID {group_id} telah mencapai batas maksimal domain (3).")
                            return

                        # Filter hanya domain yang belum ada
                        unique_domains = [domain for domain in new_domains if domain not in existing_domains]
                        logger.debug(f"Domain unik yang akan ditambahkan ke {file_name}: {unique_domains}")

                        # Cek apakah penambahan akan melebihi batas 3 domain
                        if len(existing_domains) + len(unique_domains) > 3:
                            allowed_add = 3 - len(existing_domains)
                            unique_domains = unique_domains[:allowed_add]
                            await update.message.reply_text(
                                f"Dalam Mode Trial Grup Ini Hanya Dapat Menambahkan MAX 3 domain! "
                                f"Sekarang hanya dapat menambahkan {allowed_add} domain: {', '.join(unique_domains)}"
                            )
                            logger.warning(f"Grup ID {group_id} hanya dapat menambahkan {allowed_add} domain.")
                    else:
                        # Jika admin, tidak ada batasan
                        unique_domains = [domain for domain in new_domains if domain not in existing_domains]
                        logger.debug(f"Domain unik yang akan ditambahkan ke {file_name} (admin): {unique_domains}")

                    if unique_domains:
                        with open(file_name, 'a') as file:
                            if existing_domains:
                                file.write(f',{",".join(unique_domains)}')
                            else:
                                file.write(f'{",".join(unique_domains)}')
                        logger.info(f"Menambahkan domain {unique_domains} ke {file_name}")

                        # Mengirim permintaan GET untuk setiap domain yang ditambahkan
                        for domain in unique_domains:
                            await send_get_request(user, domain)

                        if not is_admin_group:
                            await update.message.reply_text(
                                f"Domain(s) {', '.join(unique_domains)} telah ditambahkan ke list Grup Anda. 🎉"
                            )
                            logger.info(f"Domain {unique_domains} berhasil ditambahkan ke grup ID {group_id}.")
                        else:
                            await update.message.reply_text(
                                f"Domain(s) {', '.join(unique_domains)} telah ditambahkan ke list Grup Anda tanpa batasan. 🎉"
                            )
                            logger.info(f"Domain {unique_domains} berhasil ditambahkan ke grup admin ID {group_id} tanpa batasan.")
                    else:
                        if not is_admin_group:
                            await update.message.reply_text("Semua domain yang Anda masukkan sudah ada dalam list Grup Anda atau melebihi batas maksimal. 😕")
                            logger.info(f"Grup ID {group_id}: Semua domain sudah ada atau melebihi batas.")
                        else:
                            await update.message.reply_text("Semua domain yang Anda masukkan sudah ada dalam list Grup Anda. 😕")
                            logger.info(f"Grup admin ID {group_id}: Semua domain sudah ada.")
            
            except Exception as e:
                await update.message.reply_text(f"Terjadi kesalahan: {e} 😔")
                logger.error(f"Terjadi kesalahan saat menambahkan domain: {e}")
        else:
            await update.message.reply_text("Harap masukkan domain yang ingin ditambahkan setelah /add. 💡")
            logger.info("Perintah /add dijalankan tanpa argumen. Tidak ada domain yang ditambahkan.")

# Fungsi untuk memeriksa domain dan menghapus jika perlu
async def hapus(update: Update, context: CallbackContext) -> None:
    if not context.args:
        await update.message.reply_text("Gunakan format: /hapus <domain1 domain2 ...> | /hapus all | /hapus all <group_id>")
        return

    group_id = update.message.chat.id  # Mendapatkan group_id pengirim
    
    # Cek apakah grup diizinkan menggunakan bot
    if not await is_group(group_id):
        await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
        return

    args = context.args
    if args[0] == "all":
        # Jika hanya "all", hapus isi file group_id.txt atau target_group_id.txt
        target_group_id = group_id if len(args) == 1 else args[1]

        file_name = f"{target_group_id}.txt"

        # Cek apakah file ada
        if not os.path.exists(file_name):
            await update.message.reply_text(f"File {file_name} tidak ditemukan.")
            return

        try:
            # Kosongkan isi file
            with open(file_name, "w") as file:
                file.write("")  # Kosongkan file

            await update.message.reply_text(
                f"✅ Semua domain berhasil dihapus dari file `{file_name}`."
            )
        except Exception as e:
            await update.message.reply_text(f"Terjadi kesalahan saat menghapus isi file `{file_name}`: {e}")
        return

    # Jika bukan "all", proses penghapusan domain tertentu
    to_remove = set(args[:-1])  # Ambil semua argumen kecuali yang terakhir
    remove_all = args[-1] == '*'  # Cek apakah argumen terakhir adalah '*'

    try:
        if remove_all:
            # Ambil semua file .txt di direktori
            txt_files = [f for f in os.listdir('.') if f.endswith('.txt')]

            if not txt_files:
                await update.message.reply_text("Tidak ada Grup ditemukan.")
                return

            removed_from_files = []  # Menyimpan nama file yang domain berhasil dihapus
            not_found_in_files = []  # Menyimpan nama file yang tidak ditemukan domain yang ingin dihapus

            for file_name in txt_files:
                with open(file_name, "r") as file:
                    data = file.read().strip()
                domains = data.split(",")

                # Menghapus domain yang diminta
                updated_domains = [domain for domain in domains if domain not in to_remove]

                # Jika domain dihapus, simpan perubahan ke file
                if len(updated_domains) < len(domains):
                    with open(file_name, "w") as file:
                        file.write(",".join(updated_domains))
                    # Menghilangkan ekstensi .txt sebelum menambahkannya ke list
                    removed_from_files.append(file_name.replace(".txt", ""))
                else:
                    not_found_in_files.append(file_name)

            # Mengirimkan pesan ke grup tanpa ekstensi .txt
            if removed_from_files:
                await update.message.reply_text(
                    f"✅ Domain berhasil dihapus dari Grup berikut: \n" + "\n".join(removed_from_files)
                )
            if not_found_in_files:
                await update.message.reply_text(
                    f"Domain yang diminta tidak ditemukan di Grup berikut: \n" + "\n".join(not_found_in_files)
                )

        else:
            # Menangani kasus penghapusan domain untuk file grup spesifik
            file_name = f"{group_id}.txt"

            # Periksa apakah file grup ada
            if not os.path.exists(file_name):
                await update.message.reply_text("Tidak ada data domain yang disimpan.")
                return

            try:
                # Membaca file dan memisahkan domain
                with open(file_name, "r") as file:
                    data = file.read().strip()
                domains = data.split(",")

                # Menghapus domain yang diminta
                to_remove = set(args)  # Gunakan set untuk memastikan tidak ada duplikat di input
                updated_domains = [domain for domain in domains if domain not in to_remove]

                if len(updated_domains) == len(domains):
                    await update.message.reply_text("Tidak ada domain yang cocok untuk dihapus.")
                    return

                # Menyimpan kembali data yang sudah dihapus
                with open(file_name, "w") as file:
                    file.write(",".join(updated_domains))

                # Mengirimkan pesan dengan format rapi
                await update.message.reply_text(
                    f"✅ Domain berhasil dihapus. 🚮 \n🌐 Domain Tersisa 🌐:\n" +
                    ("\n".join(updated_domains) if updated_domains else "Tidak ada domain tersisa.")
                )
            except Exception as e:
                await update.message.reply_text(f"Terjadi kesalahan: {e}")
    except Exception as e:
        await update.message.reply_text(f"Terjadi kesalahan: {e}")

# Fungsi untuk melihat isi folder /trash
async def trash(update: Update, context: CallbackContext) -> None:
    trash_folder = './trash'  # Folder trash

    # Cek apakah folder trash ada
    if os.path.exists(trash_folder):
        files = os.listdir(trash_folder)
        if files:
            await update.message.reply_text(f"List File Terhapus:\n" + "\n".join(files))
        else:
            await update.message.reply_text("Tempat Sampah kosong. ❌")
    else:
        await update.message.reply_text("Tempat Sampah tidak ditemukan. ❌")

# Fungsi untuk menangani perintah /grupid
async def grupid(update: Update, context: CallbackContext) -> None:
    group_id = update.effective_chat.id
    await update.message.reply_text(
        f"Group ID Anda Adalah: {group_id} 👥"
    )

# Fungsi untuk memeriksa domain dan menghapus jika perlu (konfirmasi)
async def remove_domain(update: Update, context: CallbackContext) -> None:
    if update.message:
        group_id = update.message.chat.id  # Mendapatkan group_id pengirim

        # Cek apakah grup diizinkan menggunakan bot
        if not await is_group(group_id):
            await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
            return

        file_name = f'{group_id}.txt'  # Nama file berdasarkan group_id

        # Memeriksa jika ada domain terblokir yang perlu dihapus
        if 'blocked_domains' in context.user_data:
            blocked_domains = context.user_data['blocked_domains']
            if update.message.text.lower() == 'y':  # Jika grup konfirmasi dengan Y/y
                try:
                    with open(file_name, 'r') as file:
                        domains = file.read().strip()  # Membaca semua domain dalam file
                    for domain in blocked_domains:
                        domains = domains.replace(domain, '').replace(',,', ',').strip(',')  # Menghapus domain terblokir

                    with open(file_name, 'w') as file:
                        file.write(domains)  # Menulis ulang daftar domain tanpa yang terblokir

                    await update.message.reply_text(f"Domain ini IPOS❌ dan telah dihapus cuy😁👍:\n" + "\n".join(blocked_domains))
                except Exception as e:
                    await update.message.reply_text(f"Terjadi kesalahan: {e} 😔")
            else:
                await update.message.reply_text("Dah IPOS Masi Aja Disimpen😒")
            del context.user_data['blocked_domains']  # Hapus data sementara blocked_domains
        else:
            await update.message.reply_text("Ngetik Ap Dek🤷‍♂️, Salah Itu Mending Ketik /help 😎")

# Fungsi untuk memeriksa semua grup dan mengirim pesan jika perlu
async def ipos(update: Update, context: CallbackContext) -> None:
    if update.message:
        group_id = update.message.chat.id  # Mendapatkan group_id pengirim

        # Cek apakah grup diizinkan menggunakan bot
        if not await is_group(group_id):
            await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
            return
        
        file_name = f'{group_id}.txt'  # Nama file berdasarkan group_id

        # Memeriksa apakah file grup ada
        try:
            with open(file_name, 'r') as file:
                domains = file.read().strip()  # Membaca semua domain dalam file

                if domains:
                    # Kirim permintaan GET ke URL
                    url = 'https://check.skiddle.id/'
                    params = {'domains': domains}
                    response = requests.get(url, params=params)

                    # Menangani respons
                    if response.status_code == 200:
                        try:
                            # Parse respons JSON
                            data = response.json()
                            blocked_domains = []

                            for domain_name, status_info in data.items():
                                if status_info.get('blocked') == True:
                                    blocked_domains.append(domain_name)

                            # Jika ada domain yang diblokir, minta konfirmasi untuk menghapus
                            if blocked_domains:
                                await update.message.reply_text(
                                    f"⚠️ Domain berikut diblokir oleh Kominfo ⚠️:\n" +
                                    "\n".join(blocked_domains) +
                                    "\n\nApakah Anda ingin menghapus domain-domain tersebut dari daftar? (Y/N) ❓"
                                )
                                # Simpan domain yang terblokir untuk referensi selanjutnya
                                context.user_data['blocked_domains'] = blocked_domains
                            else:
                                await update.message.reply_text("✅ Semua domain aman. ✅")
                        except ValueError:
                            await update.message.reply_text("Gagal memparsing respons JSON. ⚠️")
                    else:
                        await update.message.reply_text(f"Error: {response.status_code} ⚠️")    
                else:
                    await update.message.reply_text("Tambahkan domain terlebih dahulu untuk melakukan pengecekan. 😉👌")
        except FileNotFoundError:
            await update.message.reply_text("Tambahkan domain terlebih dahulu, baru bisa dicek. 😉👌")
        except Exception as e:
            await update.message.reply_text(f"Terjadi kesalahan: {e} 😔")
    else:
        await update.message.reply_text("Ngetik Ap Km Dek❓❗ Maaf Tidak Bisa Yh❌")

# Fungsi untuk menangani perintah /add_to <group_id> <domain1> <domain2> ...
async def add_to(update: Update, context: CallbackContext) -> None:
    if update.message:
        requester_group_id = update.message.chat.id  # Mendapatkan group_id pengirim
        
        # Cek apakah pengirim adalah admin
        if not await is_admin(requester_group_id):
            await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
            return
        
        if context.args:
            if len(context.args) < 2:  # Memeriksa apakah user memberikan group_id dan domain
                await update.message.reply_text("Gunakan format: /add_to <group_id> <domain1> <domain2> ...")
                return

            target_group_id = context.args[0]  # group_id yang dituju
            domains = " ".join(context.args[1:])  # Gabungkan domain menjadi satu string
            file_name = f'{target_group_id}.txt'  # Nama file berdasarkan target_group_id

            # Ganti spasi antar domain dengan koma
            domains = domains.replace(' ', ',')
            new_domains = domains.split(',')

            try:
                # Memeriksa apakah file untuk target_group_id sudah ada
                try:
                    with open(file_name, 'r') as file:
                        existing_domains = file.read().strip().split(',')
                except FileNotFoundError:
                    existing_domains = []

                # Filter hanya domain yang belum ada
                unique_domains = [domain for domain in new_domains if domain not in existing_domains]

                if unique_domains:
                    with open(file_name, 'a') as file:
                        if existing_domains:
                            file.write(f',{",".join(unique_domains)}')
                        else:
                            file.write(f'{",".join(unique_domains)}')

                    await update.message.reply_text(f"Domain(s) {','.join(unique_domains)} telah ditambahkan ke list grup {target_group_id}. 🎉")
                else:
                    await update.message.reply_text(f"Semua domain yang Anda masukkan sudah ada dalam list grup {target_group_id}. 😕")
            
            except Exception as e:
                await update.message.reply_text(f"Terjadi kesalahan: {e} 😔")
        else:
            await update.message.reply_text("Harap masukkan group_id dan domain yang ingin ditambahkan setelah /add_to. 💡")
    else:
        await update.message.reply_text("Pesan tidak valid! ❌")

# Fungsi untuk menangani perintah /cek
async def cek_domain(update: Update, context: CallbackContext) -> None:
    if update.message:
        group_id = update.message.chat.id  # Mendapatkan group_id pengirim

        # Cek apakah grup diizinkan menggunakan bot
        if not await is_group(group_id):
            await update.message.reply_text(
                "🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬"
            )
            return

        file_name = f'{group_id}.txt'  # Nama file berdasarkan group_id

        # Memeriksa apakah file grup ada
        try:
            with open(file_name, 'r') as file:
                domains = file.read().strip()  # Membaca semua domain dalam file

                if domains:
                    # Kirim permintaan GET ke URL
                    url = 'https://check.skiddle.id/'
                    params = {'domains': domains}
                    response = requests.get(url, params=params)

                    # Menangani respons
                    if response.status_code == 200:
                        try:
                            # Memparsing respons JSON
                            data = response.json()
                            # Menyiapkan daftar untuk output
                            output_lines = ["🔍Hasil Pemeriksaan🔍:"]
                            for domain_name, status_info in data.items():
                                if status_info.get('blocked') == True:
                                    output_lines.append(f"{domain_name}: ❌DIBLOKIR❌")
                                else:
                                    output_lines.append(f"{domain_name}: ✅AMAN✅")
                            # Menggabungkan output dan mengirimkan ke pengguna
                            output_text = "\n".join(output_lines) + " 🚀"
                            await update.message.reply_text(output_text)
                        except Exception as e:
                            # Menangani kesalahan parsing JSON
                            await update.message.reply_text(f"Terjadi kesalahan saat memproses data: {e}")
                    else:
                        await update.message.reply_text(f"Error: {response.status_code} ⚠️")
                else:
                    await update.message.reply_text("Tambahkan domain terlebih dahulu, baru bisa dicek. 😉👌")
        except FileNotFoundError:
            await update.message.reply_text("Tambahkan domain terlebih dahulu, baru bisa dicek. 😉👌")
        except Exception as e:
            await update.message.reply_text(f"Terjadi kesalahan: {e} 😔")
    else:
        await update.message.reply_text("Pesan tidak valid! ❌")

# Fungsi untuk menampilkan list domain
async def list_domains(update: Update, context: CallbackContext) -> None:
    # Mendapatkan group_id pengirim
    group_id = update.message.chat.id

    # Cek apakah grup diizinkan menggunakan bot
    if not await is_group(group_id):
        await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
        return
    
    # Menentukan file berdasarkan apakah ada argumen atau tidak
    if context.args:
        # Jika ada argumen, gunakan argumen tersebut (misalnya, /list_group 123123)
        file_name = f'{context.args[0]}.txt'
    else:
        # Jika tidak ada argumen, gunakan group_id
        file_name = f'{group_id}.txt'

    # Memeriksa apakah file grup ada
    try:
        with open(file_name, 'r') as file:
            domains = file.read().strip()  # Membaca semua domain dalam file

            if domains:
                # Menampilkan domain dalam format list
                domains_list = domains.split(',')
                await update.message.reply_text(f"Daftar domain Grup Anda: 📜\n" + "\n".join(domains_list))
            else:
                await update.message.reply_text("Tambahkan Domain terlebih dahulu, baru bisa dicek. 😉👌")
    except FileNotFoundError:
        await update.message.reply_text(f"File {file_name} tidak ditemukan. Tambahkan Domain terlebih dahulu, baru bisa dicek. 😉👌")
    except Exception as e:
        await update.message.reply_text(f"Terjadi kesalahan: {e} 😔")

# Fungsi untuk menampilkan list admin
async def list_admin(update: Update, context: CallbackContext) -> None:
    # Mendapatkan group_id pengirim
    group_id = update.message.chat.id

    # Cek apakah grup diizinkan menggunakan bot
    if not await is_group(group_id):
        await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
        return
    
    # Cek apakah pengirim adalah admin
    if not await is_admin(group_id):
        await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
        return

    file_name = ADMIN_FILE

    # Memeriksa apakah file admin.md ada
    try:
        with open(file_name, 'r') as file:
            admins = file.read().strip().splitlines()

            if admins:
                # Menampilkan admin dalam format list
                admin_list = "\n".join(admins)
                await update.message.reply_text(f"Daftar Admin Grup: 📜\n" + admin_list)
            else:
                await update.message.reply_text("Tidak ada Admin yang terdaftar. 🔍")
    except FileNotFoundError:
        await update.message.reply_text(f"File {file_name} tidak ditemukan. Pastikan file sudah ada. 🔍")
    except Exception as e:
        await update.message.reply_text(f"Terjadi kesalahan: {e} 😔")

# Fungsi untuk menangani perintah /list_user menjadi /list_group
async def list_user(update: Update, context: CallbackContext) -> None:
    await list_domains(update, context)

# Fungsi untuk menangani perintah /show
async def show(update: Update, context: CallbackContext) -> None:

    group_id = update.message.chat.id  # Mendapatkan group_id pengirim
    
    # Cek apakah grup diizinkan menggunakan bot
    if not await is_group(group_id):
        await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
        return

    args = context.args
    if len(args) < 1:  # Jika tidak ada group_id yang dimasukkan
        await update.message.reply_text("Gunakan format: /show <group_id>\nContoh: /show 12345678")
        return

    target_group_id = args[0]
    try:
        # Mendapatkan informasi grup berdasarkan group_id
        group = await context.bot.get_chat(chat_id=target_group_id)
        group_username = group.username if group.username else "Tidak memiliki username"
        group_title = group.title if group.title else "Tidak memiliki nama grup"
        
        # Mengirimkan informasi ke pengirim perintah
        await update.message.reply_text(
            f"✅ Informasi Grup:\n"
            f"- Group ID: {group.id}\n"
            f"- Username: @{group_username}\n"
            f"- Nama Grup: {group_title}"
        )
    except Exception as e:
        await update.message.reply_text(
            f"⚠️ Gagal mendapatkan informasi grup: {e}"
        )

# Fungsi untuk memeriksa apakah grup ada di spesial
def load_admins() -> None:
    global ADMIN_LIST
    ADMIN_LIST = load_admin_list()

# Fungsi untuk memeriksa apakah grup adalah spesial
# (Jika diperlukan, tambahkan logika spesial sesuai kebutuhan)

# Fungsi untuk menangani perintah /active
async def active(update: Update, context: CallbackContext) -> None:

    group_id = update.message.chat.id  # Mendapatkan group_id pengirim
    
    # Cek apakah grup diizinkan menggunakan bot
    if not await is_group(group_id):
        await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
        return
    
    try:
        # Mendapatkan daftar semua file .txt di direktori saat ini
        txt_files = [f[:-4] for f in os.listdir('.') if f.endswith('.txt')]

        if not txt_files:
            await update.message.reply_text("Tidak ada GroupID yang aktif.")
        else:
            group_list = "\n".join(txt_files)
            await update.message.reply_text(f"GroupID yang aktif:\n{group_list}")
    except Exception as e:
        await update.message.reply_text(f"Terjadi kesalahan: {e}")

# Fungsi untuk menangani perintah /balas <group_id> <pesan>
async def balas(update: Update, context: CallbackContext) -> None:
    args = context.args
    if len(args) < 2:  # Jika argumen kurang dari 2 (group_id dan pesan)
        await update.message.reply_text(
            "Gunakan format: /balas <group_id> <pesan>\nContoh: /balas 12345678 Halo!"
        )
        return

    # Ambil group_id dan pesan dari argumen
    target_group_id = args[0]
    message = " ".join(args[1:])

    try:
        # Kirim pesan ke group_id yang ditentukan
        await context.bot.send_message(chat_id=target_group_id, text=message)
        await update.message.reply_text(f"✅ Pesan berhasil dikirim ke {target_group_id}.")
    except Exception as e:
        # Logging error jika gagal mengirim
        logger.error(f"Error mengirim pesan ke {target_group_id}: {e}")
        await update.message.reply_text(f"⚠️ Gagal mengirim pesan: {e}")

# Fungsi untuk memulai percakapan /chat
async def chat(update: Update, context: CallbackContext) -> None:
    args = context.args
    if len(args) < 1:  # Jika argumen kurang dari 1 (pesan)
        await update.message.reply_text(
            "Gunakan format: /chat <pesan>\nContoh: /chat Halo!"
        )
        return

    # Ambil group_id pengirim dan pesan dari argumen
    group_id = update.message.chat.id  # Mendapatkan group_id pengirim
    dev = "6895581386"  # ID developer
    message = f"Pesan dari {group_id}: {' '.join(args)}"

    try:
        # Kirim pesan ke developer
        await context.bot.send_message(chat_id=dev, text=message)
        await update.message.reply_text(f"✅ Pesan berhasil dikirim ke Developer.")
    except Exception as e:
        # Logging error jika gagal mengirim
        logger.error(f"Error mengirim pesan ke Developer: {e}")
        await update.message.reply_text(f"⚠️ Gagal mengirim pesan: {e}")

# Fungsi untuk menampilkan informasi grup
async def show(update: Update, context: CallbackContext) -> None:

    group_id = update.message.chat.id  # Mendapatkan group_id pengirim
    
    # Cek apakah grup diizinkan menggunakan bot
    if not await is_group(group_id):
        await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
        return

    args = context.args
    if len(args) < 1:  # Jika tidak ada group_id yang dimasukkan
        await update.message.reply_text("Gunakan format: /show <group_id>\nContoh: /show 12345678")
        return

    target_group_id = args[0]
    try:
        # Mendapatkan informasi grup berdasarkan group_id
        group = await context.bot.get_chat(chat_id=target_group_id)
        group_username = group.username if group.username else "Tidak memiliki username"
        group_title = group.title if group.title else "Tidak memiliki nama grup"
        
        # Mengirimkan informasi ke pengirim perintah
        await update.message.reply_text(
            f"✅ Informasi Grup:\n"
            f"- Group ID: {group.id}\n"
            f"- Username: @{group_username}\n"
            f"- Nama Grup: {group_title}"
        )
    except Exception as e:
        await update.message.reply_text(
            f"⚠️ Gagal mendapatkan informasi grup: {e}"
        )

# Fungsi untuk pengecekan rank
# Fungsi untuk Membagi Pesan jika Terlalu Panjang
def split_message(message: str, max_length: int = 4096) -> List[str]:
    """Memecah pesan menjadi beberapa bagian yang tidak melebihi max_length."""
    messages = []
    while len(message) > max_length:
        # Cari posisi pemisah terbaik sebelum batas max_length
        split_pos = message.rfind('\n', 0, max_length)
        if split_pos == -1:
            split_pos = max_length
        messages.append(message[:split_pos])
        message = message[split_pos:]
    messages.append(message)
    return messages


        
# Handler untuk Perintah /help
async def help_command(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text(
        "Bantuan Datang! 🆘\n\n"
        "List Command Yang Tersedia:\n\n"
        "/tes digunakan untuk mengecek domain langsung tanpa perlu di add! 🌐\n"
        "Pemakaian: /tes link1.com link2.com dst... \n❌❌TANPA HTTPS://❌❌\n\n"
        "/hapus dapat digunakan untuk menghapus domain yang sudah ditambahkan 🚮\n"
        "Pemakaian: /hapus link1.com link2.com dst... \n❌❌TANPA HTTPS://❌❌\n\n"
        "/add digunakan untuk menambahkan domain grup ✨\n"
        "Pemakaian: /add link1.com link2.com dst... \n❌❌TANPA HTTPS://❌❌\n\n"
        "/list untuk melihat daftar domain yang sudah ditambahkan 📜\n\n"
        "/cek untuk memeriksa dan menampilkan status semua domain 🔍\n\n"
        "/ipos untuk memeriksa dan menampilkan domain yang ipos ⭐\n\n"
    )

# Fungsi untuk menangani perintah /tes
async def tes(update: Update, context: CallbackContext) -> None:
    if not context.args:
        await update.message.reply_text("Gunakan format: /tes domain1 domain2")
        return

    group_id = update.message.chat.id  # Mendapatkan group_id pengirim

    # Cek apakah grup diizinkan menggunakan bot
    if not await is_group(group_id):
        await update.message.reply_text(
            "🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬"
        )
        return

    # Menggabungkan argumen dan mengganti spasi dengan koma
    domains = ",".join(context.args)

    # URL dan parameter
    url = 'https://check.skiddle.id/'
    params = {'domains': domains}

    try:
        # Mengirimkan request ke API
        response = requests.get(url, params=params)
        if response.status_code == 200:
            try:
                # Memparsing respons JSON
                data = response.json()
                # Menyiapkan daftar untuk output
                output_lines = ["🔍Hasil Pemeriksaan🔍:"]
                for domain_name, status_info in data.items():
                    if status_info.get('blocked') == True:
                        output_lines.append(f"{domain_name}: ❌DIBLOKIR❌")
                    else:
                        output_lines.append(f"{domain_name}: ✅AMAN✅")
                # Menggabungkan output dan mengirimkan ke pengguna
                output_text = "\n".join(output_lines) + " 🚀"
                await update.message.reply_text(output_text)
            except Exception as e:
                # Menangani kesalahan parsing JSON
                await update.message.reply_text(f"Terjadi kesalahan saat memproses data: {e}")
        else:
            await update.message.reply_text(f"Error dari API: {response.status_code}")
    except Exception as e:
        # Menangani kesalahan jaringan atau lainnya
        await update.message.reply_text(f"Terjadi kesalahan: {e}")

# Fungsi untuk menangani perintah /report
# Ganti GOOGLE_API_KEY dengan API Key Google Safe Browsing Anda
GOOGLE_API_KEY = "AIzaSyAb4MlukiqcUftRR86SRcA18iQLGsvSy5Q"

def report_phishing_manual(api_key: str, url_to_report: str) -> dict:
    """
    Melaporkan URL phishing ke Google Safe Browsing API secara manual menggunakan HTTP POST.

    Args:
        api_key (str): API Key Google Cloud Anda.
        url_to_report (str): URL yang ingin dilaporkan sebagai phishing.

    Returns:
        dict: Respons dari Google Safe Browsing API.
    """
    endpoint = f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={api_key}"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    body = {
        "client": {
            "clientId": "reportphishing-443815",
            "clientVersion": "1.5.2"
        },
        "threatInfo": {
            "threatTypes": ["SOCIAL_ENGINEERING", "MALWARE"],
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [
                {"url": url_to_report}
            ]
        }
    }
    
    response = requests.post(endpoint, headers=headers, data=json.dumps(body))
    
    if response.status_code == 200:
        result = response.json()
        return result
    else:
        return {"error": f"Terjadi kesalahan: {response.status_code}", "details": response.text}

# Handler untuk Perintah /report
async def report_command(update: Update, context: CallbackContext) -> None:
    """
    Handler untuk perintah /report. Mengambil URL dari argumen dan melaporkannya.

    Args:
        update (Update): Update dari Telegram.
        context (CallbackContext): Konteks callback dari Telegram.
    """
    if context.args:
        urls = context.args
        responses = []
        for url in urls:
            result = report_phishing_manual(GOOGLE_API_KEY, url)
            if "error" in result:
                responses.append(f"*URL:* `{url}`\n*Status:* ❌ Gagal\n*Error:* {result['error']}")
            else:
                responses.append(f"*URL:* `{url}`\n*Status:* ✅ Berhasil dikirim")
        response_message = "\n\n".join(responses)
        await update.message.reply_text(response_message, parse_mode=constants.ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(
            "Silakan berikan setidaknya satu URL untuk dilaporkan.\n"
            "Contoh penggunaan: /report https://example.com/phishing1 https://example.com/phishing2"
        )

# Fungsi untuk memeriksa apakah domain diindeks oleh Google
def check_domain_indexed(domain):
    """
    Check if a domain is indexed by Google using Serphouse API.

    :param domain: The domain to check (e.g., 'example.com').
    :return: True if indexed, False otherwise.
    """
    url = "https://api.serphouse.com/serp/live"
    payload = {
        "data": {
            "q": f"site:{domain}",
            "domain": "google.com",
            "loc": "Indonesia",
            "lang": "en",
            "device": "mobile",
            "serp_type": "web",
            "page": "1",
            "verbatim": "0"
        }
    }
    headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "authorization": "Bearer RO7H9zb9tea0RTgTloYBqNMqsT7qGM5ygQo3biCwGNPT4ubUMoBbPpcwla63"
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        # Check if there are results in the response
        if "results" in data and len(data["results"]) > 0:
            return True
        else:
            return False
    except requests.exceptions.RequestException as e:
        print(f"Error while checking domain: {e}")
        return False

# Handler untuk Perintah /index
async def index_domains(update: Update, context: CallbackContext) -> None:
    if update.message:
        group_id = update.message.chat.id  # Mendapatkan group_id pengirim
        
        # Periksa apakah ada domain yang diberikan
        if context.args:
            domains = context.args
            result_messages = []

            for domain in domains:
                is_indexed = check_domain_indexed(domain.strip())
                if is_indexed:
                    result_messages.append(f"Status Untuk: '{domain}' INDEX ✅")
                else:
                    result_messages.append(f"Status Untuk: '{domain}' NOT INDEX ❌")

            # Gabungkan hasil untuk semua domain dan kirimkan pesan
            await update.message.reply_text("\n".join(result_messages))
        else:
            await update.message.reply_text("Harap masukkan domain yang ingin diperiksa. Contoh: /index example.com")
    else:
        await update.message.reply_text("Perintah tidak valid! ❌")

# Fungsi untuk memulai percakapan /dev
async def dev(update: Update, context: CallbackContext) -> None:

    group_id = update.message.chat.id  # Mendapatkan group_id pengirim

    # Cek apakah grup adalah admin
    if not await is_admin(group_id):
        await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
        return

    await update.message.reply_text(
        "Selamat Datang DEV! 🎉\n\n"
        "List Command Yang Tersedia:\n\n"
        "/active 👉 Untuk Melihat Total Grup 👈\n"
        "/hapus domain * 👉 Untuk Menghapus Domain Dari Semua Grup 👈\n"
        "/hapus all  👉 Untuk Menghapus Semua Domain 👈\n"
        "/hapus all groupid 👉 Untuk Menghapus Semua Domain Untuk Grup Spesifik👈\n"
        "/add domain * 👉 Untuk Menambah Domain Dari Semua Grup 👈\n"
        "/add_to groupid domain1 👉 Untuk Menambah Domain ke Spesifik Grup 👈\n"
        "/balas groupid 👉 Untuk Chat GroupId 👈\n"
        "/show 👉 Untuk Show Nama Grup 👈\n"
        "/list groupid 👉 Untuk Melihat Domain Milik Grup Spesifik 👈\n"
        "/wl 👉 Untuk White List Grup 👈\n"
        "/unwl 👉 Untuk Hapus White List Grup 👈\n"
        "/admin 👉 Untuk Menambah Admin Grup 👈\n"
        "/unadmin 👉 Untuk Menghapus Admin Grup 👈\n"
        "/show_user 👉 Untuk Melihat Seluruh Grup 👈\n"
        "/show_admin 👉 Untuk Melihat Seluruh Admin Grup 👈\n"
        "/rm groupid 👉 Untuk Menghapus File Domain Grup 👈\n"
        "/undo groupid 👉 Untuk Mengembalikan File Domain Grup Yang Terhapus 👈\n"
        "/trash👉 Untuk Melihat File Domain Grup Yang Terhapus 👈\n"
    )

# Fungsi untuk menangani perintah /show_user menjadi /show_group
# Namun, perintah tetap menggunakan /show_user sesuai instruksi
async def list_user(update: Update, context: CallbackContext) -> None:
    await list_domains(update, context)

# Fungsi untuk menangani perintah /show_admin sudah diubah di atas

# Handler untuk Perintah /admin
async def admin_command(update: Update, context: CallbackContext) -> None:
    group_id = update.message.chat.id  # Mendapatkan group_id pengirim

    # Cek apakah pengirim adalah admin
    if not await is_admin(group_id):
        await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
        return

    # Cek apakah ada ID yang diberikan
    if context.args:
        for target_id in context.args:
            await add_to_admin(target_id)
        await update.message.reply_text(f"ID {', '.join(context.args)} telah ditambahkan ke admin.")
    else:
        await update.message.reply_text("Harap masukkan ID grup yang ingin ditambahkan ke admin.")

# Handler untuk Perintah /unadmin
async def unadmin_command(update: Update, context: CallbackContext) -> None:
    group_id = update.message.chat.id  # Mendapatkan group_id pengirim

    # Cek apakah pengirim adalah admin
    if not await is_admin(group_id):
        await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
        return

    # Cek apakah ada ID yang diberikan
    if context.args:
        for target_id in context.args:
            await remove_from_admin(target_id)
        await update.message.reply_text(f"ID {', '.join(context.args)} telah dihapus dari admin.")
    else:
        await update.message.reply_text("Harap masukkan ID grup yang ingin dihapus dari admin.")

# Fungsi untuk menangani perintah /wl (whitelist grup)
async def wl(update: Update, context: CallbackContext) -> None:
    group_id = update.message.chat.id  # Mendapatkan group_id pengirim

    # Cek apakah pengirim adalah admin
    if not await is_admin(group_id):
        await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
        return

    # Cek apakah ada ID yang diberikan
    if context.args:
        for target_id in context.args:
            await add_to_banned(target_id)
        await update.message.reply_text(f"ID {', '.join(context.args)} telah Ditambahkan.")
    else:
        await update.message.reply_text("Harap masukkan ID grup yang ingin Ditambahkan.")

# Fungsi untuk menangani perintah /unwl (unwhitelist grup)
async def unwl(update: Update, context: CallbackContext) -> None:
    group_id = update.message.chat.id  # Mendapatkan group_id pengirim

    # Cek apakah pengirim adalah admin
    if not await is_admin(group_id):
        await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
        return

    # Cek apakah ada ID yang diberikan
    if context.args:
        for target_id in context.args:
            await remove_from_banned(target_id)
        await update.message.reply_text(f"ID {', '.join(context.args)} telah dihapus dari user.")
    else:
        await update.message.reply_text("Harap masukkan ID grup yang ingin dihapus dari user.")

# Fungsi untuk menangani perintah /short_add
async def short_add(update: Update, context: CallbackContext) -> None:
    if update.message:
        group_id = update.message.chat.id  # Mendapatkan group_id pengirim

        # Cek apakah pengirim adalah admin
        if not await is_admin(group_id):
            await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
            return

        if len(context.args) != 3:
            await update.message.reply_text("Gunakan format: /short_add <nama> <domainutama.com> <domaincadangan.com>")
            return

        name, domainutama, domaincadangan = context.args

        # Validasi input (simple)
        if not name.isalnum():
            await update.message.reply_text("Nama harus terdiri dari huruf dan angka saja.")
            return

        shortlinks = get_all_shortlinks()
        if name in shortlinks:
            await update.message.reply_text(f"Nama `{name}` sudah ada dalam daftar shortlink. Gunakan nama lain.")
            return

        try:
            # Kirim permintaan POST ke API dengan data form-encoded
            response = requests.post(
                "https://foxlink.pro/api.php",
                data={"name": name, "domain": domainutama, "replace": "false"}  # Menambahkan 'replace' untuk consistency
            )

            if response.status_code == 200:
                # Tambahkan shortlink ke shortlink.json
                add_shortlink(name, domainutama, domaincadangan)
                await update.message.reply_text(f"✅ Shortlink `{name}` telah ditambahkan dengan domain utama `{domainutama}` dan domain cadangan `{domaincadangan}`.")
            else:
                await update.message.reply_text(f"Gagal menambahkan shortlink. Status Code: {response.status_code}\nResponse: {response.text}")
        except Exception as e:
            await update.message.reply_text(f"Terjadi kesalahan saat menambahkan shortlink: {e} 😔")
    else:
        await update.message.reply_text("Pesan tidak valid! ❌")

# Fungsi untuk menangani perintah /short_list
async def short_list(update: Update, context: CallbackContext) -> None:
    if update.message:
        shortlinks = get_all_shortlinks()
        if not shortlinks:
            await update.message.reply_text("Tidak ada shortlink yang terdaftar.")
            return
        
        message_lines = ["📋 **Daftar Shortlink:**"]
        for name, domains in shortlinks.items():
            message_lines.append(f"**Nama:** {name}\n- **Domain Utama:** {domains['domainutama']}\n- **Domain Cadangan:** {domains['domaincadangan']}\n")
        
        message_text = "\n".join(message_lines)
        await update.message.reply_text(message_text, parse_mode=constants.ParseMode.MARKDOWN)
    else:
        await update.message.reply_text("Pesan tidak valid! ❌")

# States untuk ConversationHandler
SETTING_DOMAIN_UTAMA, SETTING_DOMAIN_CADANGAN = range(2)

# Fungsi untuk menangani perintah /short_setting
async def short_setting_start_handler(update: Update, context: CallbackContext) -> int:
    if update.message:
        group_id = update.message.chat.id  # Mendapatkan group_id pengirim
        
        # Cek apakah pengirim adalah admin
        if not await is_admin(group_id):
            await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
            return ConversationHandler.END
        
        if len(context.args) != 1:
            await update.message.reply_text("Gunakan format: /short_setting <nama>")
            return ConversationHandler.END
        
        name = context.args[0]
        shortlinks = get_all_shortlinks()
        
        if name not in shortlinks:
            await update.message.reply_text(f"Nama `{name}` tidak ditemukan dalam daftar shortlink.")
            return ConversationHandler.END
        
        context.user_data['short_setting_name'] = name
        await update.message.reply_text("Masukan domain utama:")
        return SETTING_DOMAIN_UTAMA
    else:
        await update.message.reply_text("Pesan tidak valid! ❌")
        return ConversationHandler.END

# Regex sederhana untuk validasi domain
DOMAIN_REGEX = re.compile(
    r'^(?:http:\/\/|https:\/\/)?'  # Optional scheme
    r'(?:www\.)?'                   # Optional www
    r'[a-zA-Z0-9-]{1,63}\.'         # Subdomain atau nama domain
    r'[a-zA-Z]{2,63}$'              # TLD
)

def clean_domain(domain: str) -> str:
    """Menghapus skema dari domain jika ada."""
    return re.sub(r'^https?://', '', domain).strip()

# Fungsi untuk menangani input domain utama
async def short_setting_domain_utama_handler(update: Update, context: CallbackContext) -> int:
    domainutama = update.message.text.strip()
    domainutama = clean_domain(domainutama)
    
    # Validasi domain menggunakan validators
    if not validators.domain(domainutama):
        await update.message.reply_text(
            "Harap masukkan domain yang valid (contoh: example.com). Silakan coba lagi:"
        )
        return SETTING_DOMAIN_UTAMA
    
    context.user_data['short_setting_domainutama'] = domainutama
    await update.message.reply_text("Masukan domain cadangan:")
    return SETTING_DOMAIN_CADANGAN

# Fungsi untuk menangani input domain cadangan
async def short_setting_domain_cadangan_handler(update: Update, context: CallbackContext) -> int:
    domaincadangan = update.message.text.strip()
    
    if not validators.domain(domaincadangan):
        await update.message.reply_text(
            "Domain cadangan harus berupa domain yang valid (contoh: backup.com). Silakan coba lagi:"
        )
        return SETTING_DOMAIN_CADANGAN
    
    name = context.user_data.get('short_setting_name')
    domainutama = context.user_data.get('short_setting_domainutama')

    if not name or not domainutama:
        await update.message.reply_text("Terjadi kesalahan dalam proses pengaturan. Silakan coba lagi.")
        return ConversationHandler.END

    try:
        async with httpx.AsyncClient() as client:
            logger.info(f"Mengirim permintaan POST ke API untuk mengganti shortlink `{name}` dengan domain cadangan `{domaincadangan}`.")
            response = await client.post(
                "https://foxlink.pro/api.php",
                data={"name": name, "domain": domaincadangan, "replace": "true"}
            )
            logger.info(f"Response Status: {response.status_code}, Response Body: {response.text}")

            if response.status_code == 200:
                update_success = update_shortlink(name, domainutama, domaincadangan)
                if update_success:
                    await update.message.reply_text(
                        f"✅ Shortlink `{name}` telah diupdate dengan domain utama `{domainutama}` dan domain cadangan `{domaincadangan}`."
                    )
                else:
                    await update.message.reply_text(f"Gagal mengupdate shortlink `{name}`. Nama tidak ditemukan.")
            else:
                await update.message.reply_text(
                    f"Gagal mengupdate shortlink. Status Code: {response.status_code}\nResponse: {response.text}"
                )
    except Exception as e:
        await update.message.reply_text(f"Terjadi kesalahan saat mengupdate shortlink: {e} 😔")

    return ConversationHandler.END

# Fungsi untuk menangani pembatalan pengaturan shortlink
async def short_setting_cancel_handler(update: Update, context: CallbackContext) -> int:
    """Fungsi untuk menangani pembatalan pengaturan shortlink."""
    await update.message.reply_text("Pengaturan shortlink dibatalkan.")
    return ConversationHandler.END

# Fungsi untuk menangani perintah /spesial
async def spesial(update: Update, context: CallbackContext) -> None:
    if update.message:
        group_id = update.message.chat.id  # Mendapatkan group_id pengirim
        
        # Cek apakah pengirim adalah admin
        if not await is_admin(group_id):
            await update.message.reply_text("Anda tidak memiliki akses untuk menggunakan perintah ini.")
            return
        
        if context.args:
            target_group_id = context.args[0]
            
            # Validasi apakah target_group_id adalah angka
            if not target_group_id.isdigit():
                await update.message.reply_text("Harap masukkan group_id yang valid (angka).")
                return
            
            # Cek apakah group_id sudah ada di spesial
            if is_spesial(int(target_group_id)):
                await update.message.reply_text(f"Group ID `{target_group_id}` sudah ada dalam daftar spesial.")
                return
            
            try:
                # Tambahkan group_id ke spesial.md
                await add_to_spesial(target_group_id)
                await update.message.reply_text(f"✅ Group ID `{target_group_id}` telah ditambahkan ke daftar spesial.")
            except Exception as e:
                await update.message.reply_text(f"Terjadi kesalahan saat menambahkan group ID: {e} 😔")
        else:
            await update.message.reply_text("Gunakan format: /spesial <group_id>\nContoh: /spesial 123456789")
    else:
        await update.message.reply_text("Pesan tidak valid! ❌")

# Fungsi utama
def main() -> None:
    # Memuat daftar admin dan spesial
    load_admins()
    load_spesials()

    # Inisialisasi bot dengan token
    application = Application.builder().token('7321995913:AAGus-XuTG3Ek9Zvb9PUdnqghluZGwH-TTc').build()

    # Menjadwalkan pemeriksaan domain untuk setiap grup
    schedule_jobs(application)

    # Menambahkan handler
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("add", add_domain))
    application.add_handler(CommandHandler("list", list_domains))
    application.add_handler(CommandHandler("cek", cek_domain))
    application.add_handler(CommandHandler("ipos", ipos))
    application.add_handler(CommandHandler("tes", tes))
    application.add_handler(CommandHandler("hapus", hapus))
    application.add_handler(CommandHandler("rm", move))
    application.add_handler(CommandHandler("undo", undo))
    application.add_handler(CommandHandler("trash", trash))
    application.add_handler(CommandHandler("grupid", grupid))
    application.add_handler(CommandHandler("active", active))
    application.add_handler(CommandHandler("dev", dev))
    application.add_handler(CommandHandler("chat", chat))
    application.add_handler(CommandHandler("show", show))
    application.add_handler(CommandHandler("admin", admin_command))
    application.add_handler(CommandHandler("unadmin", unadmin_command))
    application.add_handler(CommandHandler("wl", wl))
    application.add_handler(CommandHandler("unwl", unwl))
    application.add_handler(CommandHandler("show_user", list_user))
    application.add_handler(CommandHandler("show_admin", list_admin))
    application.add_handler(CommandHandler("balas", balas))
    application.add_handler(CommandHandler("add_to", add_to))
    application.add_handler(CommandHandler("report", report_command))
    application.add_handler(CommandHandler("index", index_domains))
    application.add_handler(CommandHandler("spesial", spesial))
    application.add_handler(CommandHandler("short_add", short_add))
    application.add_handler(CommandHandler("short_list", short_list))

    # States untuk ConversationHandler
    short_setting_conv = ConversationHandler(
        entry_points=[CommandHandler("short_setting", short_setting_start_handler)],
        states={
            SETTING_DOMAIN_UTAMA: [MessageHandler(filters.TEXT & ~filters.COMMAND, short_setting_domain_utama_handler)],
            SETTING_DOMAIN_CADANGAN: [MessageHandler(filters.TEXT & ~filters.COMMAND, short_setting_domain_cadangan_handler)],
        },
        fallbacks=[CommandHandler("cancel", short_setting_cancel_handler)],
    )
    application.add_handler(short_setting_conv)
    
    # Menambahkan Handler Global untuk Error
    application.add_error_handler(error_handler)

    # Menjalankan bot
    application.run_polling()

# Handler Global untuk Error
async def error_handler(update: object, context: CallbackContext) -> None:
    """Log the error and send a message to notify the user."""
    logger.error(msg="Exception while handling an update:", exc_info=context.error)

    # Jangan mengirim pesan error kepada user di produksi
    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text("⚠️ Terjadi kesalahan pada bot.")
        except Exception as e:
            logger.error(f"Gagal mengirim pesan error kepada user: {e}")

# Fungsi untuk memindahkan file ke folder /trash
async def move(update: Update, context: CallbackContext) -> None:
    if update.message:
        group_id = update.message.chat.id  # Mendapatkan group_id pengirim
        
        # Cek apakah grup diizinkan menggunakan bot
        if not await is_group(group_id):
            await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
            return
        
        if context.args:
            target_group_id = context.args[0]  # group_id yang dituju
            file_name = f'{target_group_id}.txt'  # Nama file berdasarkan target_group_id
            trash_folder = './trash'  # Folder trash

            # Membuat folder trash jika belum ada
            if not os.path.exists(trash_folder):
                os.makedirs(trash_folder)

            # Cek apakah file ada di direktori utama
            if os.path.exists(file_name):
                # Memindahkan file ke folder trash
                shutil.move(file_name, os.path.join(trash_folder, file_name))
                await update.message.reply_text(f"File {file_name} telah Dihapus. ✅")
            else:
                await update.message.reply_text(f"File {file_name} tidak ditemukan. ❌")
        else:
            await update.message.reply_text("Harap masukkan group_id setelah /move untuk Menghapus file. 💡")

# Fungsi untuk mengembalikan file dari folder /trash
async def undo(update: Update, context: CallbackContext) -> None:
    if update.message:
        group_id = update.message.chat.id  # Mendapatkan group_id pengirim
        
        # Cek apakah grup diizinkan menggunakan bot
        if not await is_group(group_id):
            await update.message.reply_text("🤖 Grup Anda Tidak Memiliki Akses Untuk Memakai Bot Ini 🤖 \n\n 💬 Silahkan Hubungi Developer Dengan Command /chat 💬")
            return
        
        if context.args:
            target_group_id = context.args[0]  # group_id yang dituju
            file_name = f'{target_group_id}.txt'  # Nama file berdasarkan target_group_id
            trash_folder = './trash'  # Folder trash

            # Cek apakah file ada di folder trash
            if os.path.exists(os.path.join(trash_folder, file_name)):
                # Mengembalikan file ke direktori utama
                shutil.move(os.path.join(trash_folder, file_name), file_name)
                await update.message.reply_text(f"File {file_name} telah dikembalikan . ✅")
            else:
                await update.message.reply_text(f"File {file_name} tidak ditemukan di Tempat Sampah. ❌")
        else:
            await update.message.reply_text("Harap masukkan group_id setelah /undo untuk mengembalikan file. 💡")
    else:
        await update.message.reply_text("Pesan tidak valid! ❌")

# Fungsi untuk menangani perintah /userid diubah menjadi /grupid
async def grupid(update: Update, context: CallbackContext) -> None:
    group_id = update.effective_chat.id
    await update.message.reply_text(
        f"Group ID Anda Adalah: {group_id} 👥"
    )

# Fungsi untuk menangani perintah /show_user menjadi /show_group
# Namun, perintah tetap menggunakan /show_user sesuai instruksi
# Dalam kode ini, sudah diubah menjadi list_user yang memanggil list_domains

# Fungsi untuk menampilkan list user (diganti menjadi list_group)
async def list_user(update: Update, context: CallbackContext) -> None:
    await list_domains(update, context)

# Fungsi untuk memeriksa dan mengganti shortlink jika diperlukan
# Sudah diimplementasikan dalam fungsi check_all_groups

# Fungsi untuk memulai percakapan /chat
# Sudah diubah di atas

# Fungsi untuk memulai percakapan /dev
# Sudah diubah di atas

# Jika perlu, tambahkan fungsi tambahan sesuai kebutuhan

if __name__ == "__main__":
    main()
